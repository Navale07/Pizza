<?php
if(isset($_POST['submit'])) {
    if(empty($nombre)) {
        echo "<p class='error'>* Agrega tu nombre </p>";
    } 
    if(empty($apellido)) {
        echo "<p class='error'>* Agrega tu apellido</p>";
    } 
    if(empty($direccion)) {
        echo "<p class='error'>* Agrega tu direccion </p>";
    } 
}
?>