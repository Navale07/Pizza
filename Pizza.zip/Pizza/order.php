<!DOCTYPE html>
<html>
<head>
	<title>Orden Confirmada</title>
	<style type="text/css">
		td { padding: 30px; } </style>
	<link rel="stylesheet" href="sytleorden.css">
</head>
<body>
	
<?php 
	
	if (isset($_POST['submit'])) {
		echo "<p>Estima/o <strong>" . $_POST['Nombre'] . "</strong>, tu orden ha sido creada.";
			echo "<br> Gracias por preferirnos.";
		echo "</p>";		
	}
	
	echo "<p>Este es el detalle del pedido.</p>";

	if (isset($_POST['submit'])) {
		echo "<p>Porcion de pizza <strong>" . $_POST['Tamaño'] . "</strong>";			
		echo "</p>";		
	}

	
	echo "<table border=\"1\" cellpadding=\"5\">";
		echo "<tr>";		    
			echo "<th>Topping</th>";
			echo "<th>Tamaño</th>";
			echo "<th>Bebidas</th>";
			echo "<th colspan=\"\">Delivery Time</th>";
			echo "<th>Observaciones</th>";
		echo "</tr>";
		echo "<tr>";
			echo "<td>" . $_POST['type'] . "</td>";
			echo "<td>" . $_POST['size'] . "</td>";
			echo "<td>" . $_POST['extra'] . "</td>";
			echo "<td>" . $_POST['delivery_time'] . "</td>";
			echo "<td>" . $_POST['instuctions'] . "</td>";
		echo "</tr>";
	echo "</table>";

	echo "<br>";
	echo "<br>";
	echo "<br>";
?>


<footer>
	<p>

	</p>

</footer>

</body>
</html>