<!DOCTYPE html>
<html>
<head>
	<title>Ordenar Pizza</title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>

	<img src="pizza.jpg" class="logo">	
	<h2>EL SABOR DE LA PIZZA</h2>
	<h4>Formulario de pedido</h4>

	
	<form method="POST" action="order.php"> 
		
		
		<table align="center" cellpadding="5" border="2">
			<tr>
				<td>
					
					<p>
						<label>Nombre: </label>
						<input type="text" name="Nombre" id="Nombre" required>
					</p>

					<p>
						<label>Apellido:</label>
						<input type="text" name="Apellido" id="Apellido"required>
					</p>					
								
					<p>
						<label>Direccion: </label>
						<input type="text" name="direccion" id="direccion"required>
					</p>	
				</td>
				<td colspan="2">
					
					<p>
						<label>Telefono: </label>
						<input type="number" name="telefono" id="telefono"required>
					</p>

					
					<p>
						<label>Ciudad: </label>
						<input type="text" name="ciudad" id="ciudad"required>
					</p>

					<p>
						<label>Correo: </label>
						<input type="email" name="email" id="email"required>
					</p>
					
					
				
				</td>
			</tr>
                
			<h3>Tipos de pizza:</h3>
			<form action="">
				<center><div>
				<label><input type="checkbox" id="cbox1" value="checkbox_1"> Jamon y queso</label>
                <label><input type="checkbox" id="cbox2" value="checkbox_2"> Napolitana </label>
                <label><input type="checkbox" id="cbox3" value="checkbox_3"> Mozzarella </label> 
				</div></center>
				<h3>Seleccione :</h3>
				<label for="Tamaño"></label>
				<center><select name="Tamaño" id="Tamaño">
				    <option value="1"></option>
					<option value="2">Personal (1)</option>
					<option value="3">Mediana (4)</option>
					<option value="4">Familiar (8)</option>
					<option value="5">Extra Grande (16)</option>

				</select></center>
			</form>			
			
				<th>Topping</th>
				<th>Tamaño</th>
				<th>Bebidas</th>				
			</tr>

			
			<tr>
				<td><input type="radio" name="type" value="Extra Queso" required>Extra Queso </td> 
				<td><input type="radio" name="size" value="Pequeña" required value="Pequeña">Pequeña</td>
				<td><input type="radio" name="extra" value="Jugo Natural" required>Jugo Natural</td>
			</tr>
 
			</tr>

			
			<tr>
				<td><input type="radio" name="type" value="Tocineta">Tocineta</td>
				<td><input type="radio" name="size" value="Grande">Grande</td>
				<td><input type="radio" name="extra" value="Cerveza">Cerveza</td>
			</tr>

			
			
			<tr>
				<td>
					<label>Tiempo de entrega : </label>
				</td>
				<td colspan="2">
					<input type="time" name="delivery_time" id="delivery_time">
				</td>
			</tr>

			
			<tr>
				<td>
					<label>Observaciones: </label>
				</td>
				<td colspan="2">
					<textarea rows="5" cols="30" name="instuctions" id="instuctions"></textarea>
				</td>
			</tr>

			
			<tr>
				<td colspan="3" align="center">
					<button type="submit" name="submit" id="submit">Confirmar</button>
				</td>
			</tr>

		</table>
	</form>

</body>
</html>